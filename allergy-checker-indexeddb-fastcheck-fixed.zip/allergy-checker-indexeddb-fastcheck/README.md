# Allergy Checker AI - IndexedDB

サーバーなしの構成です。
公開アプリと管理アプリを分割し、設定・記事・ランキング・イベントはブラウザのIndexedDBに保存します。

## 構成

```text
public-app/     公開アプリ
admin-app/      管理アプリ
shared/assets/  共通CSS/JS/IndexedDB
```

デプロイ後のURL:

```text
/               公開アプリ
/admin/         管理アプリ
```

## 重要

この版ではGemini API KeyをブラウザのIndexedDBに保存します。公開運用ではAPIキーをサーバー側のSecretに移してください。

IndexedDBは同一オリジン内で共有されます。GitHub Pagesの同じサイト内で `/` と `/admin/` を使う場合は共有できますが、別ドメインに分けると共有されません。

## GitHub Pages

リポジトリ直下に以下を置いてください。

```text
allergy-checker-indexeddb.zip
.github/workflows/deploy-pages.yml
```

GitHubの Settings > Pages > Source は GitHub Actions にしてください。

## 使い方

1. `/admin/` を開く
2. Configで Request Mode を `mock` または `direct` にする
3. directの場合はGemini API KeyとModelを入力
4. PromptsでSystem Promptを確認・編集
5. Ads / AffiliateでAmazon・楽天・AdSense設定を入力
6. Articlesでブログ記事を追加
7. `/` で画像チェックを試す

## 本番移行でやること

- Gemini API Keyをクライアントから削除し、サーバー側Secretへ移す
- 検索ランキングをIndexedDBからサーバー側DBへ移す
- ads.txtのPublisher IDを本物に変更
- robots.txt / sitemap.xml のURLを実URLに変更
- プライバシーポリシー・利用規約・問い合わせ先を運営者情報に合わせて修正


## AdMax広告

広告枠のプレースホルダー表示は削除済みです。AdMaxのURLは管理画面の「Ads / Affiliate > AdMax > AdMax Script URL」から差し替えできます。HTML内の複数箇所を直接編集する必要はありません。


## AdMax表示修正
AdMaxスクリプトは動的appendでは表示されない場合があるため、広告枠では iframe の srcdoc 内に script タグを出力する方式にしています。


## AdMax広告について

AdMaxは動的appendや後読み込みでは表示されないケースがあるため、この版では公開ページのHTMLに静的なscriptタグを直接配置しています。

設置済みページ:

- `public-app/index.html`
- `public-app/blog.html`
- `public-app/article.html`
- `public-app/rankings.html`

広告URLを一括で差し替える場合は、展開後のプロジェクト直下で次を実行してください。

```bash
node tools/replace-admax-url.js https://adm.shinobi.jp/s/新しいID
```

プレースホルダー文言は表示しません。広告タグが配信されない場合は空白になります。
