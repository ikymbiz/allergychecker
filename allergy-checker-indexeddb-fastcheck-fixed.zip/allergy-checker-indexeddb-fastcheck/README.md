# Allergy Checker AI - IndexedDB

サーバーなしの構成です。
公開アプリと管理アプリを分割し、設定・記事・ランキング・イベントはブラウザのIndexedDBに保存します。

## 構成

```text
public-app/     公開アプリ
admin-app/      管理アプリ
shared/assets/  共通CSS/JS/IndexedDB
```

デプロイ後のURL:

```text
/               公開アプリ
/admin/         管理アプリ
```

## 重要

この版ではGemini API KeyをブラウザのIndexedDBに保存します。公開運用ではAPIキーをサーバー側のSecretに移してください。

IndexedDBは同一オリジン内で共有されます。GitHub Pagesの同じサイト内で `/` と `/admin/` を使う場合は共有できますが、別ドメインに分けると共有されません。

## GitHub Pages

リポジトリ直下に以下を置いてください。

```text
allergy-checker-indexeddb.zip
.github/workflows/deploy-pages.yml
```

GitHubの Settings > Pages > Source は GitHub Actions にしてください。

## 使い方

1. `/admin/` を開く
2. Configで Request Mode を `mock` または `direct` にする
3. directの場合はGemini API KeyとModelを入力
4. PromptsでSystem Promptを確認・編集
5. Ads / AffiliateでAmazon・楽天・AdSense設定を入力
6. Articlesでブログ記事を追加
7. `/` で画像チェックを試す

## 本番移行でやること

- Gemini API Keyをクライアントから削除し、サーバー側Secretへ移す
- 検索ランキングをIndexedDBからサーバー側DBへ移す
- ads.txtのPublisher IDを本物に変更
- robots.txt / sitemap.xml のURLを実URLに変更
- プライバシーポリシー・利用規約・問い合わせ先を運営者情報に合わせて修正


## AdMax広告

public-app/index.html、blog.html、article.html、rankings.html の広告枠に、指定されたAdMaxスクリプトを追加済みです。
