/*
  AdMax top-safe helper
  - Does not load AdMax dynamically.
  - Does not move the ad.
  - Only protects the app header from being covered when the ad network renders a top banner.
*/
(function () {
  'use strict';

  function appContainer() {
    return document.querySelector('.container');
  }

  function ensureTitleText() {
    var title = document.querySelector('.container .header h1, .container .header h3');
    if (!title) return;
    if (!String(title.textContent || '').trim()) {
      title.textContent = 'Allergy Checker AI';
    }
  }

  function isPotentialTopAd(el, container) {
    if (!el || el === container || el.nodeType !== 1) return false;
    var tag = (el.tagName || '').toLowerCase();
    if (/^(script|style|link|meta|title)$/.test(tag)) return false;
    if (el.classList && el.classList.contains('container')) return false;
    if (el.classList && el.classList.contains('top-admax-shell')) return false;

    var r;
    try { r = el.getBoundingClientRect(); } catch (e) { return false; }
    if (!r || r.width < Math.min(240, window.innerWidth * 0.45) || r.height < 24) return false;
    if (r.top > 160) return false;

    var text = ((el.id || '') + ' ' + (el.className || '') + ' ' + (el.getAttribute && (el.getAttribute('src') || el.getAttribute('href') || '') || '')).toLowerCase();
    if (/(admax|shinobi|adm\.shinobi)/.test(text)) return true;
    try {
      if (el.querySelector('img, object, embed')) return true;
    } catch (e) {}
    return false;
  }

  function protectHeader() {
    ensureTitleText();
    var container = appContainer();
    if (!container) return;

    var cRect = container.getBoundingClientRect();
    var extra = 0;
    var children = Array.prototype.slice.call(document.body.children || []);

    children.forEach(function (el) {
      if (!isPotentialTopAd(el, container)) return;
      var r = el.getBoundingClientRect();
      var style = window.getComputedStyle ? getComputedStyle(el) : null;
      var positioned = style && (style.position === 'fixed' || style.position === 'absolute' || style.position === 'sticky');
      var overlaps = r.bottom > cRect.top;

      if (positioned || overlaps) {
        try {
          el.style.maxWidth = '100%';
          if (positioned) el.style.zIndex = '1';
        } catch (e) {}
        extra = Math.max(extra, Math.ceil(r.bottom - cRect.top + 12));
      }
    });

    if (extra > 0 && extra < 180) {
      document.body.classList.add('admax-top-overlap-fixed');
      container.style.marginTop = extra + 'px';
    }
  }

  function schedule() {
    [0, 80, 200, 500, 1000, 2000, 4000].forEach(function (ms) {
      setTimeout(protectHeader, ms);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', schedule);
  } else {
    schedule();
  }

  try {
    new MutationObserver(function () { setTimeout(protectHeader, 0); })
      .observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}
})();
