const SETTINGS_ALLERGENS_JA = ['小麦','乳','卵','えび','かに','そば','落花生','ピーナッツ','くるみ','カシューナッツ','大豆','ごま','アーモンド','オレンジ','キウイ','牛肉','鶏肉','豚肉','さけ','さば','いか','いくら','バナナ','もも','やまいも','りんご','ゼラチン','グルテン','ナッツ','Vegan'];
const SETTINGS_ALLERGENS_EN = ['wheat','milk','egg','shrimp','crab','buckwheat','peanut','walnut','cashew','soy','sesame','almond','orange','kiwi','beef','chicken','pork','salmon','mackerel','squid','banana','peach','apple','gelatin','gluten','nuts','vegan'];

async function initSettingsPage() {
  await seedInitialDataIfNeeded();
  const config = await getConfig();
  document.querySelectorAll('[data-site-name]').forEach(el => el.textContent = config.siteName || 'Allergy Checker AI');
  document.getElementById('lang-selector').value = localStorage.getItem('ui_lang') || 'ja';
  document.getElementById('my-diet').value = localStorage.getItem('my_diet') || '';
  renderSettingsPills();
}

function currentSettingsLang() { return document.getElementById('lang-selector').value || 'ja'; }
function currentDietList() { return toArray(document.getElementById('my-diet').value); }

function renderSettingsPills() {
  const wrap = document.getElementById('allergen-pills');
  const current = currentDietList();
  const list = currentSettingsLang() === 'ja' ? SETTINGS_ALLERGENS_JA : SETTINGS_ALLERGENS_EN;
  wrap.innerHTML = list.map(item => {
    const active = current.some(v => normalizeText(v) === normalizeText(item));
    return `<span class="pill ${active ? 'active' : ''}" onclick="togglePill('${escapeAttribute(item)}')">${escapeHtml(item)}</span>`;
  }).join('');
}

function togglePill(item) {
  const input = document.getElementById('my-diet');
  const list = currentDietList();
  const normalized = normalizeText(item);
  const exists = list.some(v => normalizeText(v) === normalized);
  const next = exists ? list.filter(v => normalizeText(v) !== normalized) : [...list, item];
  input.value = next.join(', ');
  renderSettingsPills();
}

function saveUserSettings() {
  localStorage.setItem('ui_lang', document.getElementById('lang-selector').value);
  localStorage.setItem('my_diet', document.getElementById('my-diet').value);
  alert('保存しました');
}

function resetUserSettings() {
  localStorage.removeItem('ui_lang');
  localStorage.removeItem('my_diet');
  document.getElementById('lang-selector').value = 'ja';
  document.getElementById('my-diet').value = '';
  renderSettingsPills();
  alert('リセットしました');
}
