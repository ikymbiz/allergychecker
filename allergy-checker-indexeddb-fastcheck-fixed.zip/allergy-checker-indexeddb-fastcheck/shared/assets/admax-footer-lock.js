/*
  AdMax footer lock
  - The AdMax script tag itself stays statically written inside the footer.
  - This file does not create or dynamically load an ad script.
  - If the ad network writes its generated banner above the app, this script moves
    that generated banner back into the footer slot.
*/
(function () {
  'use strict';

  var SLOT_SELECTOR = '.footer-admax[data-admax-footer="true"], #footer-admax-slot, .footer-admax';
  var RE = /(adm\.shinobi\.jp|shinobi\.jp|admax|忍者AdMax)/i;
  var timersStarted = false;

  function slot() {
    return document.querySelector(SLOT_SELECTOR);
  }

  function attr(el, name) {
    try { return (el.getAttribute && el.getAttribute(name)) || ''; } catch (e) { return ''; }
  }

  function hasAdmaxSignature(el) {
    if (!el || el.nodeType !== 1) return false;
    if (RE.test(attr(el, 'src')) || RE.test(attr(el, 'href')) || RE.test(attr(el, 'id')) || RE.test(attr(el, 'class'))) return true;
    var nodes = [];
    try { nodes = el.querySelectorAll('[src],[href],script,[id],[class]'); } catch (e) { nodes = []; }
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (RE.test(attr(n, 'src')) || RE.test(attr(n, 'href')) || RE.test(attr(n, 'id')) || RE.test(attr(n, 'class'))) return true;
    }
    return false;
  }

  function directBodyChild(el) {
    var current = el;
    while (current && current.parentElement && current.parentElement !== document.body) {
      current = current.parentElement;
    }
    return current;
  }

  function shouldNotMove(el, target) {
    if (!el || el.nodeType !== 1) return true;
    if (el === target || target.contains(el)) return true;
    if (el.matches && el.matches('script,style,link,meta,title')) return true;
    if (el.classList && el.classList.contains('container')) return true;
    if (el.closest && el.closest('.container') && !hasAdmaxSignature(el)) return true;
    return false;
  }

  function moveIntoFooter(el) {
    var target = slot();
    if (!target || shouldNotMove(el, target)) return false;
    var top = directBodyChild(el) || el;
    if (shouldNotMove(top, target)) top = el;
    if (shouldNotMove(top, target)) return false;
    if (!hasAdmaxSignature(top) && !hasAdmaxSignature(el)) return false;
    top.setAttribute('data-admax-moved-to-footer', 'true');
    target.appendChild(top);
    return true;
  }

  function sweep() {
    var target = slot();
    if (!target || !document.body) return;

    var children = Array.prototype.slice.call(document.body.children || []);
    for (var i = 0; i < children.length; i++) {
      var child = children[i];
      if (!shouldNotMove(child, target) && hasAdmaxSignature(child)) {
        moveIntoFooter(child);
      }
    }

    var generated = [];
    try { generated = document.querySelectorAll('[src*="shinobi"],[href*="shinobi"],[src*="admax"],[href*="admax"],[id*="admax"],[class*="admax"],[id*="shinobi"],[class*="shinobi"]'); } catch (e) { generated = []; }
    for (var j = 0; j < generated.length; j++) {
      var node = generated[j];
      if (target.contains(node)) continue;
      moveIntoFooter(node);
    }
  }

  function startTimers() {
    if (timersStarted) return;
    timersStarted = true;
    [0, 50, 150, 400, 900, 1600, 3000, 5000].forEach(function (ms) {
      setTimeout(sweep, ms);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { sweep(); startTimers(); });
  } else {
    sweep(); startTimers();
  }

  try {
    var observer = new MutationObserver(function (mutations) {
      var shouldSweep = false;
      for (var i = 0; i < mutations.length; i++) {
        for (var j = 0; j < mutations[i].addedNodes.length; j++) {
          var n = mutations[i].addedNodes[j];
          if (n && n.nodeType === 1 && hasAdmaxSignature(n)) {
            shouldSweep = true;
            break;
          }
        }
        if (shouldSweep) break;
      }
      if (shouldSweep) setTimeout(sweep, 0);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}
})();
