async function initBlogList() {
  await seedInitialDataIfNeeded();
  const config = await getConfig();
  applyContentChrome(config);
  const articles = await listArticles({ status: 'published' });
  const root = document.getElementById('article-list');
  root.innerHTML = articles.length ? articles.map(article => `
    <article class="article-item">
      <h3><a href="article.html?slug=${encodeURIComponent(article.slug)}">${escapeHtml(article.title)}</a></h3>
      <p>${escapeHtml(article.excerpt || '')}</p>
      <div>${(article.tags || []).map(tag => `<span class="tag">${escapeHtml(tag)}</span>`).join('')}</div>
    </article>
  `).join('') : '<div class="notice">記事がまだありません。管理アプリから記事を作成してください。</div>';
  renderAdSlotContent('article', config);
}

async function initArticlePage() {
  await seedInitialDataIfNeeded();
  const config = await getConfig();
  applyContentChrome(config);
  const slug = new URLSearchParams(location.search).get('slug');
  const article = slug ? await getArticleBySlug(slug) : null;
  const root = document.getElementById('article-detail');
  if (!article || article.status !== 'published') {
    root.innerHTML = '<div class="notice warning-notice">記事が見つかりません。</div>';
    return;
  }
  await incrementArticleView(article.id);
  document.title = `${article.title} | ${config.siteName || 'Allergy Checker AI'}`;
  root.innerHTML = `
    <article class="article-body">
      <h1>${escapeHtml(article.title)}</h1>
      <p>${escapeHtml(article.excerpt || '')}</p>
      <div>${(article.tags || []).map(tag => `<span class="tag">${escapeHtml(tag)}</span>`).join('')}</div>
      <div class="notice warning-notice">${escapeHtml(config.safetyDisclaimer || DEFAULT_CONFIG.safetyDisclaimer)}</div>
      <div class="card">${markdownToHtml(article.body || '')}</div>
    </article>
  `;
  renderAdSlotContent('article', config);
}

async function initRankingsPage() {
  await seedInitialDataIfNeeded();
  const config = await getConfig();
  applyContentChrome(config);
  const rows = await listRankings(100);
  const root = document.getElementById('ranking-list');
  root.innerHTML = rows.length ? `
    <div class="table-wrap">
      <table>
        <thead><tr><th>#</th><th>キーワード</th><th>カテゴリ</th><th>検索</th><th>クリック</th><th>スコア</th></tr></thead>
        <tbody>${rows.map((r, i) => `<tr><td>${i + 1}</td><td>${escapeHtml(r.keyword)}</td><td>${escapeHtml(r.category || '')}</td><td>${Number(r.count || 0)}</td><td>${Number(r.clickCount || 0)}</td><td>${Number(r.score || 0)}</td></tr>`).join('')}</tbody>
      </table>
    </div>
  ` : '<div class="notice">ランキングデータはまだありません。判定後に検索リンクが表示されると記録されます。</div>';
  renderAdSlotContent('ranking', config);
}

function applyContentChrome(config) {
  document.querySelectorAll('[data-site-name]').forEach(el => el.textContent = config.siteName || 'Allergy Checker AI');
}

function markdownToHtml(md) {
  const lines = String(md || '').split('\n');
  return lines.map(line => {
    if (line.startsWith('# ')) return `<h1>${escapeHtml(line.slice(2))}</h1>`;
    if (line.startsWith('## ')) return `<h2>${escapeHtml(line.slice(3))}</h2>`;
    if (line.startsWith('### ')) return `<h3>${escapeHtml(line.slice(4))}</h3>`;
    if (line.startsWith('- ')) return `<p>• ${escapeHtml(line.slice(2))}</p>`;
    if (!line.trim()) return '<br>';
    return `<p>${escapeHtml(line)}</p>`;
  }).join('');
}

function getAdmaxScriptUrlContent(config) {
  const url = String((config && config.admaxScriptUrl) || DEFAULT_CONFIG.admaxScriptUrl || '').trim();
  return /^https?:\/\//i.test(url) ? url : '';
}

function renderAdmaxSlotContent(container, config) {
  if (!container) return;
  container.innerHTML = '';
  const scriptUrl = getAdmaxScriptUrlContent(config);
  if (!scriptUrl || (config && config.admaxEnabled === false)) {
    container.style.display = 'none';
    return;
  }
  container.style.display = '';
  container.classList.add('admax-slot');
  container.setAttribute('data-admax', 'true');
  const start = document.createComment(' admax ');
  const script = document.createElement('script');
  script.src = scriptUrl;
  script.async = true;
  const end = document.createComment(' admax ');
  container.appendChild(start);
  container.appendChild(script);
  container.appendChild(end);
}

function renderAdSlotContent(slot, config) {
  const container = document.querySelector(`[data-ad-slot="${slot}"]`);
  if (!container) return;
  renderAdmaxSlotContent(container, config || DEFAULT_CONFIG);
}
