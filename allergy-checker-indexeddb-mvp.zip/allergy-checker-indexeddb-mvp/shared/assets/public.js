const I18N = {
  ja: {
    scan: '🔍 スキャン開始', capture: '📸 判定する', light: '🔦 LIGHT', photo: '📁 PHOTO',
    hold: '動かさないでください...', loading: 'AI分析中...', apiMissing: '管理アプリでGemini API Keyを設定してください。',
    safe: 'OCR上は未検出', critical: '避けたい成分を検出', warning: '注意が必要です', unknown: '判定できません',
    disclaimer: 'この判定は参考情報です。購入・飲食前に必ず商品の原材料表示、アレルギー表示、メーカー公式情報を確認してください。',
    product: '商品名', category: 'カテゴリ', detected: '検出された成分', warnings: '注意表記', ingredients: 'Ingredients List', ocr: 'OCR全文', raw: 'Raw JSON',
    noMatches: '該当なし', recommendations: 'おすすめ検索', amazon: 'Amazonで探す', rakuten: '楽天で探す', custom: 'リンクを開く'
  },
  en: {
    scan: '🔍 START SCAN', capture: '📸 CAPTURE', light: '🔦 LIGHT', photo: '📁 PHOTO',
    hold: 'Hold steady...', loading: 'Analyzing...', apiMissing: 'Set Gemini API Key in the admin app first.',
    safe: 'Not detected in OCR', critical: 'Restricted ingredient detected', warning: 'Caution required', unknown: 'Unable to determine',
    disclaimer: 'This result is for reference only. Always check the product label, allergy information, and official manufacturer information before purchase or consumption.',
    product: 'Product', category: 'Category', detected: 'Detected ingredients', warnings: 'Warnings', ingredients: 'Ingredients List', ocr: 'Full OCR Text', raw: 'Raw JSON',
    noMatches: 'None', recommendations: 'Recommended Searches', amazon: 'Search on Amazon', rakuten: 'Search on Rakuten', custom: 'Open Link'
  }
};

const COMMON_ALLERGENS_JA = ['小麦','乳','卵','えび','かに','そば','落花生','ピーナッツ','くるみ','カシューナッツ','大豆','ごま','アーモンド','オレンジ','キウイ','牛肉','鶏肉','豚肉','さけ','さば','いか','いくら','バナナ','もも','やまいも','りんご','ゼラチン','グルテン','ナッツ','Vegan'];
const COMMON_ALLERGENS_EN = ['wheat','milk','egg','shrimp','crab','buckwheat','peanut','walnut','cashew','soy','sesame','almond','orange','kiwi','beef','chicken','pork','salmon','mackerel','squid','banana','peach','apple','gelatin','gluten','nuts','vegan'];

let cameraStream = null;
let currentConfig = null;

function userLang() { return localStorage.getItem('ui_lang') || 'ja'; }
function t() { return I18N[userLang()] || I18N.ja; }
function userAllergens() { return toArray(localStorage.getItem('my_diet') || ''); }

async function initPublicApp() {
  await seedInitialDataIfNeeded();
  currentConfig = await getConfig();
  applySiteChrome(currentConfig);
  const scanBtn = document.getElementById('ui-scan-btn');
  if (scanBtn) scanBtn.textContent = t().scan;
  const torchBtn = document.getElementById('ui-torch-btn');
  if (torchBtn) torchBtn.textContent = t().light;
  const photoBtn = document.getElementById('ui-photo-btn');
  if (photoBtn) photoBtn.textContent = t().photo;
  const footer = document.getElementById('safety-disclaimer');
  if (footer) footer.textContent = currentConfig.safetyDisclaimer || t().disclaimer;
  renderAdPlaceholder('main');
}

function applySiteChrome(config) {
  document.querySelectorAll('[data-site-name]').forEach(el => el.textContent = config.siteName || 'Allergy Checker AI');
  document.title = config.siteName || document.title;
}

async function handleScanButton() {
  if (!cameraStream) {
    try {
      cameraStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false });
      document.getElementById('video').srcObject = cameraStream;
      document.getElementById('video').style.display = 'block';
      document.getElementById('file-preview').style.display = 'none';
      document.getElementById('empty-preview').style.display = 'none';
      document.getElementById('scan-line').style.display = 'block';
      document.getElementById('ui-scan-btn').textContent = t().capture;
    } catch (err) {
      alert('Camera Error: ' + err.message);
    }
  } else {
    capture();
  }
}

async function capture() {
  showLoading(t().hold);
  const video = document.getElementById('video');
  const canvas = document.createElement('canvas');
  const MAX_W = 1280;
  let w = video.videoWidth;
  let h = video.videoHeight;
  if (!w || !h) { hideLoading(); alert('Camera Error'); return; }
  if (w > MAX_W) { h *= MAX_W / w; w = MAX_W; }
  canvas.width = Math.round(w);
  canvas.height = Math.round(h);
  canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.72);
  const base64 = dataUrl.split(',')[1];
  const preview = document.getElementById('file-preview');
  preview.src = dataUrl;
  preview.style.display = 'block';
  document.getElementById('empty-preview').style.display = 'none';
  stopCamera();
  analyze(base64, 'image/jpeg');
}

function stopCamera() {
  if (cameraStream) {
    cameraStream.getTracks().forEach(track => track.stop());
    cameraStream = null;
  }
  const video = document.getElementById('video');
  if (video) video.style.display = 'none';
  const scanLine = document.getElementById('scan-line');
  if (scanLine) scanLine.style.display = 'none';
  const scanBtn = document.getElementById('ui-scan-btn');
  if (scanBtn) scanBtn.textContent = t().scan;
}

async function toggleTorch() {
  if (!cameraStream) return;
  const track = cameraStream.getVideoTracks()[0];
  const capabilities = track.getCapabilities ? track.getCapabilities() : {};
  const settings = track.getSettings ? track.getSettings() : {};
  if (capabilities.torch) await track.applyConstraints({ advanced: [{ torch: !settings.torch }] });
}

function handleFileSelect(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async e => {
    const dataUrl = e.target.result;
    document.getElementById('file-preview').src = dataUrl;
    document.getElementById('file-preview').style.display = 'block';
    document.getElementById('empty-preview').style.display = 'none';
    stopCamera();
    const resized = await resizeImageDataUrl(dataUrl, 1280, 0.72);
    analyze(resized.dataUrl.split(',')[1], resized.mimeType);
  };
  reader.readAsDataURL(file);
}

async function analyze(base64, mimeType) {
  showLoading(t().loading);
  try {
    currentConfig = await getConfig();
    let result;
    if (currentConfig.requestMode === 'mock') {
      result = await analyzeMock();
    } else {
      result = await analyzeGeminiDirect(base64, mimeType, currentConfig);
    }
    result = normalizeAnalysisResult(result);
    result = applyLocalAllergenJudgement(result);
    renderResult(result);
    for (const q of result.recommendation_queries || []) {
      await logSearchEvent({ keyword: q, category: result.category, allergens: userAllergens(), source: 'scan' });
    }
  } catch (err) {
    console.error(err);
    alert((err && err.message) || String(err));
  } finally {
    hideLoading();
  }
}

async function analyzeGeminiDirect(base64, mimeType, config) {
  if (!config.geminiApiKey) throw new Error(t().apiMissing);
  const model = config.geminiModel || 'gemini-2.0-flash';
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(config.geminiApiKey)}`;
  const systemPrompt = userLang() === 'ja' ? config.systemPromptJa : config.systemPromptEn;
  const body = {
    systemInstruction: { parts: [{ text: systemPrompt }] },
    contents: [{ role: 'user', parts: [{ text: buildUserPrompt() }, { inlineData: { mimeType, data: base64 } }] }],
    generationConfig: { temperature: 0.1, topP: 0.8, topK: 40, responseMimeType: 'application/json' }
  };
  const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const json = await res.json();
  if (!res.ok) throw new Error(json?.error?.message || `Gemini API error: ${res.status}`);
  const text = json?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n').trim();
  return parseJsonFromModelText(text);
}

function buildUserPrompt() {
  return `ユーザー言語: ${userLang() === 'ja' ? 'Japanese' : 'English'}\nユーザーが避けたい成分・アレルゲン・食事制限: ${userAllergens().join(', ') || '未設定'}\n\nこの画像の食品表示を読み取り、system promptのJSONスキーマに厳密に従ってJSONのみを返してください。安全だと断定せず、OCR結果から判断できる範囲だけを返してください。代替商品は商品DBなしで使える検索キーワードとして返してください。`;
}

async function analyzeMock() {
  await new Promise(resolve => setTimeout(resolve, 700));
  const restricted = userAllergens();
  const hasWheat = restricted.some(v => /小麦|wheat|gluten/i.test(v));
  return {
    status: hasWheat ? 'danger' : 'warning',
    product_name: userLang() === 'ja' ? 'サンプル クッキー' : 'Sample Cookies',
    category: userLang() === 'ja' ? 'クッキー' : 'Cookies',
    ocr_text: userLang() === 'ja' ? '名称: クッキー\n原材料名: 小麦粉、砂糖、植物油脂、卵、食塩 / 膨張剤、香料\n一部に小麦・卵を含む\n本品製造工場では乳成分を含む製品を製造しています。' : 'Name: Cookies\nIngredients: wheat flour, sugar, vegetable oil, egg, salt, baking powder, flavoring. Contains wheat and egg. Manufactured in a facility that also processes milk.',
    ingredients: userLang() === 'ja' ? '小麦粉、砂糖、植物油脂、卵、食塩 / 膨張剤、香料' : 'wheat flour, sugar, vegetable oil, egg, salt, baking powder, flavoring',
    allergy_label: userLang() === 'ja' ? '一部に小麦・卵を含む。本品製造工場では乳成分を含む製品を製造しています。' : 'Contains wheat and egg. Manufactured in a facility that also processes milk.',
    translated_ingredients: userLang() === 'ja' ? '小麦粉、砂糖、植物油脂、卵、食塩、膨張剤、香料' : 'Wheat flour, sugar, vegetable oil, egg, salt, baking powder, flavoring',
    detected_allergens: userLang() === 'ja' ? ['小麦', '卵', '乳成分の製造ライン注意'] : ['wheat', 'egg', 'milk facility warning'],
    matches: hasWheat ? (userLang() === 'ja' ? ['小麦'] : ['wheat']) : [],
    may_contain: userLang() === 'ja' ? ['乳成分を含む製品を同じ工場で製造'] : ['Manufactured in a facility that also processes milk'],
    recommendation_queries: userLang() === 'ja' ? ['小麦不使用 クッキー', 'グルテンフリー クッキー', '米粉 クッキー アレルギー対応'] : ['wheat free cookies', 'gluten free cookies', 'allergy friendly rice flour cookies'],
    suitability_note: userLang() === 'ja' ? 'OCR結果では小麦と卵が検出され、乳成分に関する製造ライン注意もあります。購入・飲食前に必ず表示を確認してください。' : 'The OCR result detected wheat and egg, with a milk facility warning. Always verify the product label before purchase or consumption.',
    confidence: 'high', notes: []
  };
}

function normalizeAnalysisResult(data) {
  const raw = data && typeof data === 'object' ? data : {};
  let status = raw.status || 'unknown';
  if (status === 'safe') status = 'clear';
  if (!['danger', 'warning', 'clear', 'unknown'].includes(status)) status = 'unknown';
  return {
    status,
    product_name: raw.product_name || raw.productName || '不明',
    category: raw.category || '不明',
    ocr_text: raw.ocr_text || raw.ocrText || '',
    ingredients: raw.ingredients || '',
    allergy_label: raw.allergy_label || raw.allergyLabel || '',
    translated_ingredients: raw.translated_ingredients || raw.translatedIngredients || raw.ingredients || '',
    detected_allergens: toArray(raw.detected_allergens || raw.detectedAllergens),
    matches: toArray(raw.matches),
    may_contain: toArray(raw.may_contain || raw.mayContain),
    recommendation_queries: toArray(raw.recommendation_queries || raw.recommendationQueries),
    suitability_note: raw.suitability_note || raw.suitabilityNote || '',
    confidence: raw.confidence || 'low',
    notes: toArray(raw.notes)
  };
}

function applyLocalAllergenJudgement(res) {
  const restricted = userAllergens();
  const allText = [res.ocr_text, res.ingredients, res.allergy_label, res.translated_ingredients, ...(res.detected_allergens || []), ...(res.matches || [])].join('\n');
  const localMatches = restricted.filter(item => normalizeText(allText).includes(normalizeText(item)));
  const mayContainPatterns = userLang() === 'ja' ? ['同一工場','製造ライン','含む可能性','コンタミ','本品製造工場','共通の設備','同じ設備'] : ['may contain','facility','same line','shared equipment','processed in','manufactured in a facility'];
  const localMay = mayContainPatterns.filter(p => normalizeText(allText).includes(normalizeText(p)));
  const matches = uniqueArray([...(res.matches || []), ...localMatches]);
  const may_contain = uniqueArray([...(res.may_contain || []), ...localMay]);
  let status = res.status;
  if (matches.length > 0) status = 'danger';
  else if (may_contain.length > 0 && status !== 'danger') status = 'warning';
  else if (!res.ocr_text && !res.ingredients && !res.allergy_label) status = 'unknown';
  else if (!['danger', 'warning', 'unknown'].includes(status)) status = 'clear';
  return { ...res, status, matches, may_contain, recommendation_queries: ensureRecommendationQueries(res.recommendation_queries, res.category, restricted) };
}

function ensureRecommendationQueries(existing, category, restricted) {
  const arr = toArray(existing);
  if (arr.length) return uniqueArray(arr).slice(0, 8);
  const cat = category && category !== '不明' ? category : (userLang() === 'ja' ? '食品' : 'food');
  const base = restricted.length ? restricted : (userLang() === 'ja' ? ['アレルギー対応'] : ['allergy friendly']);
  return uniqueArray(base.slice(0, 4).map(x => userLang() === 'ja' ? `${x} 不使用 ${cat}` : `${x} free ${cat}`)).slice(0, 8);
}

function renderResult(res) {
  const status = getStatusInfo(res.status);
  const cfg = currentConfig || DEFAULT_CONFIG;
  document.getElementById('result-area').innerHTML = `
    <div class="alert-box ${status.className}">
      <span style="font-size:64px;">${status.emoji}</span>
      <h2>${status.label}</h2>
      <p><strong>${escapeHtml(res.product_name)}</strong></p>
      <p>${escapeHtml(res.suitability_note || cfg.safetyDisclaimer || t().disclaimer)}</p>
      <div>${res.matches.length ? res.matches.map(m => `<span class="tag tag-danger">${escapeHtml(m)}</span>`).join('') : `<span class="tag tag-success">${escapeHtml(t().noMatches)}</span>`}</div>
      <div class="notice ${res.status === 'danger' ? 'danger-notice' : res.status === 'warning' ? 'warning-notice' : ''}">${escapeHtml(cfg.safetyDisclaimer || t().disclaimer)}</div>
    </div>
    <div class="card"><h3>判定結果</h3><p><strong>${t().product}:</strong> ${escapeHtml(res.product_name)}</p><p><strong>${t().category}:</strong> ${escapeHtml(res.category)}</p><p><strong>Confidence:</strong> ${escapeHtml(res.confidence)}</p></div>
    <div class="card"><h3>${t().detected}</h3><div>${res.detected_allergens.length ? res.detected_allergens.map(m => `<span class="tag">${escapeHtml(m)}</span>`).join('') : `<span class="tag">${escapeHtml(t().noMatches)}</span>`}</div><h3 style="margin-top:16px;">${t().warnings}</h3><div>${res.may_contain.length ? res.may_contain.map(m => `<span class="tag tag-warning">${escapeHtml(m)}</span>`).join('') : `<span class="tag">${escapeHtml(t().noMatches)}</span>`}</div></div>
    <details class="card" open><summary style="cursor:pointer;font-weight:800;">${t().ingredients}</summary><div class="mono-box" style="margin-top:10px;">${escapeHtml(res.translated_ingredients || res.ingredients)}</div></details>
    <details class="card"><summary style="cursor:pointer;font-weight:800;">${t().ocr}</summary><div class="mono-box" style="margin-top:10px;">${escapeHtml(res.ocr_text)}</div></details>
    ${renderRecommendations(res.recommendation_queries, res.category)}
    <details class="card"><summary style="cursor:pointer;font-weight:800;">${t().raw}</summary><pre class="mono-box" style="margin-top:10px;">${escapeHtml(JSON.stringify(res, null, 2))}</pre></details>
  `;
}

function getStatusInfo(status) {
  if (status === 'danger') return { label: t().critical, emoji: '😫', className: 'alert-critical' };
  if (status === 'warning') return { label: t().warning, emoji: '⚠️', className: 'alert-warning' };
  if (status === 'clear') return { label: t().safe, emoji: '😊', className: 'alert-safe' };
  return { label: t().unknown, emoji: '❓', className: 'alert-unknown' };
}

function renderRecommendations(queries, category) {
  const cfg = currentConfig || DEFAULT_CONFIG;
  if (!queries.length) return '';
  return `<div class="recommendations"><h3>${t().recommendations}</h3>${queries.map(query => {
    const amazonUrl = buildAmazonUrl(query, cfg);
    const rakutenUrl = buildRakutenUrl(query, cfg);
    const customLinks = (cfg.customLinks || []).filter(x => x.enabled && x.urlTemplate).map(x => `<a class="link-button custom-link" href="${escapeAttribute(fillTemplate(x.urlTemplate, query, cfg))}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('custom','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${escapeHtml(x.label || t().custom)}</a>`).join('');
    return `<div class="recommendation-card"><h4>${escapeHtml(query)}</h4><div class="recommendation-actions"><a class="link-button amazon-link" href="${escapeAttribute(amazonUrl)}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('amazon','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${t().amazon}</a><a class="link-button rakuten-link" href="${escapeAttribute(rakutenUrl)}" target="_blank" rel="noopener noreferrer sponsored" onclick="trackAffiliateClick('rakuten','${escapeAttribute(query)}',this.href,'${escapeAttribute(category)}')">${t().rakuten}</a>${customLinks}</div></div>`;
  }).join('')}</div>`;
}

function buildAmazonUrl(query, cfg) { return fillTemplate(cfg.amazonSearchTemplate || DEFAULT_CONFIG.amazonSearchTemplate, query, cfg); }
function buildRakutenUrl(query, cfg) { return fillTemplate(cfg.rakutenSearchTemplate || DEFAULT_CONFIG.rakutenSearchTemplate, query, cfg); }
function fillTemplate(template, query, cfg) {
  const domain = String(cfg.amazonDomain || 'amazon.co.jp').replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
  return String(template)
    .replaceAll('{query}', encodeURIComponent(query))
    .replaceAll('{queryRaw}', query)
    .replaceAll('{domain}', domain)
    .replaceAll('{tag}', encodeURIComponent(cfg.amazonAssociateTag || ''))
    .replaceAll('{rakutenAffiliateId}', encodeURIComponent(cfg.rakutenAffiliateId || ''));
}

async function trackAffiliateClick(provider, keyword, url, category) {
  try { await logAffiliateClick({ provider, keyword, url, category, allergens: userAllergens() }); } catch (e) { console.warn(e); }
}
window.trackAffiliateClick = trackAffiliateClick;

function showLoading(text) { const el = document.getElementById('loading-overlay'); if (el) { el.style.display = 'flex'; document.getElementById('ui-loading-text').textContent = text || ''; } }
function hideLoading() { const el = document.getElementById('loading-overlay'); if (el) el.style.display = 'none'; }

function resizeImageDataUrl(dataUrl, maxWidth, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let w = img.width; let h = img.height;
      if (w > maxWidth) { h *= maxWidth / w; w = maxWidth; }
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(w); canvas.height = Math.round(h);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve({ dataUrl: canvas.toDataURL('image/jpeg', quality), mimeType: 'image/jpeg' });
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}

function parseJsonFromModelText(text) {
  const cleaned = String(text || '').replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```$/i, '').trim();
  try { return JSON.parse(cleaned); } catch (e) {
    const match = cleaned.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
    throw e;
  }
}

function renderAdPlaceholder(slot) {
  const container = document.querySelector(`[data-ad-slot="${slot}"]`);
  if (!container) return;
  getConfig().then(cfg => {
    if (cfg.adsenseEnabled && cfg.adsensePublisherId) {
      container.innerHTML = `<div class="ad-placeholder">AdSense広告枠: ${escapeHtml(slot)}<br>Publisher: ${escapeHtml(cfg.adsensePublisherId)}</div>`;
    } else {
      container.innerHTML = `<div class="ad-placeholder">広告枠 / Ad Placeholder</div>`;
    }
  });
}
