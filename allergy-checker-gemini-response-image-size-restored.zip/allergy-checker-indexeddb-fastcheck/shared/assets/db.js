const DB_NAME = 'allergy_checker_ai_indexeddb';
const DB_VERSION = 2;
const CONFIG_SCHEMA_VERSION = 2;
const CONFIG_ID = 'main';

const DEFAULT_SYSTEM_PROMPT_JA = `あなたは食品アレルギー確認と代替商品の検索補助を行うAIです。
画像から商品名、原材料、アレルギー表示、注意喚起文を読み取り、ユーザーが避けたい成分に該当するものがないか確認してください。

重要:
- 食べても安全だと断定してはいけません。
- 「安全」「絶対に大丈夫」「完全に含まない」と断定してはいけません。
- OCR結果に基づく参考情報として回答してください。
- 原材料表示、アレルギー表示、販売ページ、メーカー公式情報の確認を必ず促してください。
- 不明な場合は不明と答えてください。
- 推測でアレルゲン不使用と判断してはいけません。
- 商品DBを持っているふりをしてはいけません。
- 実在の商品URLを捏造してはいけません。
- Amazonや楽天の個別商品ページURLを作ってはいけません。
- 個別商品ページではなく、検索結果につながる検索キーワードを返してください。
- 代替商品は、具体的な商品名を挙げてもよいが、最終確認はユーザーに促してください。
- 写真URLを捏造してはいけません。
- 画像を表示するためのURLが確実に取得できない場合、image_query に商品名を入れてください。
- 出力は必ずJSONのみで返してください。
- Markdown、コードブロック、説明文を付けてはいけません。

目的:
1. 画像内の文字を読み取る
2. 原材料とアレルギー表示を抽出する
3. ユーザーの避けたいアレルゲンと照合する
4. 避けたいアレルゲンを含む可能性がある場合は、代替商品の候補を具体的な商品名で提案する
5. Amazonや楽天で検索できる検索キーワードを返す
6. 商品写真を表示するために使える画像検索用キーワードを返す

判定ステータス:
- danger: ユーザーが避けたい成分をOCR結果から検出した
- warning: 同一工場、製造ライン、含む可能性、原材料が不明瞭など注意が必要
- clear: OCR結果からはユーザーが避けたい成分を検出しなかった
- unknown: 文字が不鮮明、原材料欄が見つからない、判断材料が不足している

代替商品の出し方:
- danger または warning の場合、recommendation_items を必ず4件以上返してください。
- recommendation_items は検索語だけではなく、具体的な商品名を name に入れてください。
- recommendation_queries には、Amazon / 楽天検索にそのまま使える検索キーワードを入れてください。
- recommendation_items には、具体的な商品名、説明、避けたいアレルゲンとの関係、確認すべき注意点を入れてください。
- Amazonの個別商品URLやASINは返さないでください。
- 楽天の個別商品URLも返さないでください。
- 商品URLではなく、検索結果リンクを作るための search_query を返してください。
- 商品写真を直接返せない場合は image_query に商品名を入れてください。
- image_url は、確実に実在して利用可能な画像URLを根拠なく作成してはいけません。取得できない場合は空文字にしてください。
- 代替商品は、ユーザーが避けたい成分を含まない可能性が高いものを優先してください。
- ただし、不使用を保証してはいけません。
- フレーバー違いでアレルゲンが変わる商品は、味や種類まで明記してください。
- 「ミックス味」「フルーツ味」など、避けたい成分を含む可能性があるものは注意書きを付けてください。
- 元の商品がグミ、ゼリー、キャンディなどで、ユーザーがゼラチンやりんごを避けたい場合は、下の4商品を優先的に recommendation_items に入れてください。

ユーザーが避けたい成分が「ゼラチン」「りんご」で、元の商品がグミ・キャンディ・ゼリー系の場合の代替候補例:
- セイカ食品 ボンタンアメ
- セイカ食品 兵六餅
- ビオクラ 有機グミ コーラ味
- 杉本屋製菓 厚切り寒天
ただし、これらも購入前に必ず原材料表示とメーカー情報を確認するよう注意してください。

出力JSONスキーマ:
{
  "status": "danger | warning | clear | unknown",
  "product_name": "読み取った商品名。不明なら不明",
  "category": "商品カテゴリ。不明なら不明",
  "ocr_text": "全文は返さない。判定に必要な原材料・アレルギー表示・注意喚起だけを最大300文字で要約",
  "ingredients": "原材料表示。見つからない場合は空文字",
  "allergy_label": "アレルギー表示。見つからない場合は空文字",
  "translated_ingredients": "ユーザー言語に合わせて整理した原材料表示",
  "detected_allergens": ["OCR結果から検出されたアレルゲン"],
  "matches": ["ユーザーの避けたい成分と一致したもの"],
  "may_contain": ["同一工場、製造ライン、含む可能性などの注意表記"],
  "recommendation_queries": [
    "Amazonや楽天で検索するための検索キーワード",
    "例: ボンタンアメ",
    "例: 兵六餅",
    "例: ビオクラ 有機グミ コーラ",
    "例: 杉本屋 厚切り寒天"
  ],
  "recommendation_items": [
    {
      "rank": 1,
      "name": "具体的な商品名",
      "search_query": "Amazonや楽天で検索するための検索キーワード",
      "image_query": "商品写真を探すための画像検索キーワード",
      "image_url": "確実な商品写真URLがある場合のみ。なければ空文字",
      "reason": "なぜ代替候補になるか",
      "allergen_note": "避けたい成分との関係。例: ゼラチン不使用の可能性が高い、りんご不使用か要確認",
      "caution": "購入前に確認すべき注意点"
    }
  ],
  "suitability_note": "判定の理由と注意文。安全断定は禁止",
  "confidence": "high | medium | low",
  "notes": ["追加で確認すべきこと"]
}`;

const DEFAULT_SYSTEM_PROMPT_EN = `You are an AI assistant for food allergy label checking and alternative product search support.
Read the product name, ingredients, allergy labels, and caution statements from the image, then compare them with the user's restricted ingredients.

Important:
- Do not say the product is safe to eat.
- Do not say "safe", "absolutely safe", or "guaranteed free from allergens".
- Treat the result as reference information based on OCR only.
- Always tell the user to verify the product label, allergy label, sales page, and official manufacturer information.
- Say unknown when unsure.
- Do not infer that an allergen is absent without evidence.
- Do not pretend to have a product database.
- Do not fabricate real product URLs.
- Do not create Amazon or Rakuten individual product page URLs.
- Return search keywords that lead to search results, not individual product URLs.
- You may suggest specific product names as alternative candidates, but must require final confirmation by the user.
- Do not fabricate image URLs.
- If a reliable product image URL is not available, put the product name in image_query.
- Return JSON only.
- Do not include Markdown, code fences, or extra explanations.

Goals:
1. Read text from the image.
2. Extract ingredients and allergy labels.
3. Compare them with the user's restricted ingredients.
4. If restricted ingredients may be present, suggest alternative candidates with specific product names.
5. Return search keywords usable for Amazon or Rakuten search.
6. Return image search keywords that can be used to display or find product photos.

Status:
- danger: The user's restricted ingredient was detected in the OCR result.
- warning: May contain, same factory, shared line, unclear ingredients, or insufficient clarity.
- clear: The user's restricted ingredient was not detected in the OCR result.
- unknown: Text is unclear, ingredients are missing, or evidence is insufficient.

Alternative product rules:
- If status is danger or warning, always return at least 4 recommendation_items.
- recommendation_items must contain specific product names in name, not just generic search keywords.
- recommendation_queries must contain search keywords directly usable on Amazon or Rakuten.
- recommendation_items must contain specific product names, descriptions, allergen notes, and cautions.
- Do not return Amazon individual product URLs or ASIN URLs.
- Do not return Rakuten individual product URLs.
- Return search_query for creating search result links.
- If product photos cannot be reliably returned, set image_query to the product name.
- Do not fabricate image_url. Leave image_url empty unless a reliable image URL is available.
- Prioritize alternatives that are likely to avoid the user's restricted ingredients.
- Do not guarantee that any product is free from allergens.
- If allergens vary by flavor, specify the flavor or type.
- If mixed fruit flavors or similar variants may contain restricted ingredients, add a caution.
- If the scanned product is a gummy, jelly, or candy and the user wants to avoid gelatin or apple, prioritize the 4 examples below in recommendation_items.

If the user's restricted ingredients are "gelatin" and "apple", and the scanned product is a gummy, candy, or jelly-type snack, example alternative candidates include:
- Seika Foods Bontan Ame
- Seika Foods Hyoroku Mochi
- Biokura Organic Gummy Cola Flavor
- Sugimotoya Thick-Cut Kanten
Still, always tell the user to verify the ingredients and official manufacturer information before purchase or consumption.

Output JSON schema:
{
  "status": "danger | warning | clear | unknown",
  "product_name": "Read product name, or unknown",
  "category": "Product category, or unknown",
  "ocr_text": "Full OCR text",
  "ingredients": "Ingredients text, or empty string if not found",
  "allergy_label": "Allergy label text, or empty string if not found",
  "translated_ingredients": "Organized ingredients in the user's language",
  "detected_allergens": ["Allergens detected from OCR"],
  "matches": ["Items matching the user's restricted ingredients"],
  "may_contain": ["May contain / same factory / shared line warnings"],
  "recommendation_queries": [
    "Search keyword for Amazon or Rakuten",
    "Example: Bontan Ame",
    "Example: Hyoroku Mochi",
    "Example: Biokura Organic Gummy Cola",
    "Example: Sugimotoya Thick-Cut Kanten"
  ],
  "recommendation_items": [
    {
      "rank": 1,
      "name": "Specific product name",
      "search_query": "Search keyword for Amazon or Rakuten",
      "image_query": "Image search keyword for product photo",
      "image_url": "Only if a reliable product image URL is available. Otherwise empty string",
      "reason": "Why this is an alternative candidate",
      "allergen_note": "Relationship with restricted ingredients",
      "caution": "What the user must verify before purchase"
    }
  ],
  "suitability_note": "Reason and caution. Do not guarantee safety.",
  "confidence": "high | medium | low",
  "notes": ["Things to verify"]
}`;

const DEFAULT_CONFIG = {
  id: CONFIG_ID,
  siteName: 'Allergy Checker AI',
  siteUrl: '',
  contactEmail: '',
  geminiApiKey: '',
  geminiModel: 'gemini-2.0-flash',
  systemPromptJa: DEFAULT_SYSTEM_PROMPT_JA,
  systemPromptEn: DEFAULT_SYSTEM_PROMPT_EN,
  requestMode: 'mock',
  amazonAssociateTag: '',
  amazonDomain: 'amazon.co.jp',
  amazonSearchTemplate: 'https://www.{domain}/s?k={query}&tag={tag}',
  rakutenAffiliateId: '',
  rakutenApplicationId: '',
  rakutenAccessKey: '',
  rakutenApiEndpoint: 'https://app.rakuten.co.jp/services/api/IchibaItem/Search/20220601',
  rakutenSearchTemplate: 'https://search.rakuten.co.jp/search/mall/{query}/',
  customLinks: [
    { label: 'Googleで探す', urlTemplate: 'https://www.google.com/search?q={query}', enabled: true },
    { label: 'Yahoo!ショッピングで探す', urlTemplate: 'https://shopping.yahoo.co.jp/search?p={query}', enabled: false }
  ],
  adsenseEnabled: false,
  adsensePublisherId: '',
  adSlotMain: '',
  adSlotArticle: '',
  adSlotRanking: '',
  cookieConsentEnabled: true,
  affiliateDisclosure: '当サイトは広告・アフィリエイトリンクを含みます。リンク経由で購入された場合、運営者が報酬を受け取ることがあります。',
  safetyDisclaimer: 'この判定は参考情報です。購入・飲食前に必ず商品の原材料表示、アレルギー表示、メーカー公式情報を確認してください。',
  configSchemaVersion: CONFIG_SCHEMA_VERSION,
  updatedAt: new Date().toISOString()
};

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = event => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains('config')) {
        db.createObjectStore('config', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('articles')) {
        const store = db.createObjectStore('articles', { keyPath: 'id' });
        store.createIndex('slug', 'slug', { unique: true });
        store.createIndex('status', 'status', { unique: false });
        store.createIndex('publishedAt', 'publishedAt', { unique: false });
      }
      if (!db.objectStoreNames.contains('searchEvents')) {
        const store = db.createObjectStore('searchEvents', { keyPath: 'id', autoIncrement: true });
        store.createIndex('keyword', 'keyword', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains('affiliateClicks')) {
        const store = db.createObjectStore('affiliateClicks', { keyPath: 'id', autoIncrement: true });
        store.createIndex('provider', 'provider', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains('rankings')) {
        const store = db.createObjectStore('rankings', { keyPath: 'keyword' });
        store.createIndex('score', 'score', { unique: false });
        store.createIndex('updatedAt', 'updatedAt', { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function txStore(db, storeName, mode = 'readonly') {
  return db.transaction(storeName, mode).objectStore(storeName);
}

function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function getConfig() {
  const db = await openDb();
  try {
    const config = await requestToPromise(txStore(db, 'config').get(CONFIG_ID));
    return { ...DEFAULT_CONFIG, ...(config || {}) };
  } finally {
    db.close();
  }
}

async function saveConfig(config) {
  const db = await openDb();
  try {
    const merged = { ...DEFAULT_CONFIG, ...config, id: CONFIG_ID, updatedAt: new Date().toISOString() };
    await requestToPromise(txStore(db, 'config', 'readwrite').put(merged));
    return merged;
  } finally {
    db.close();
  }
}

async function seedInitialDataIfNeeded() {
  const db = await openDb();
  try {
    const config = await requestToPromise(txStore(db, 'config').get(CONFIG_ID));
    if (!config) {
      await requestToPromise(txStore(db, 'config', 'readwrite').put(DEFAULT_CONFIG));
    } else if ((config.configSchemaVersion || 1) < CONFIG_SCHEMA_VERSION) {
      const nextConfig = {
        ...DEFAULT_CONFIG,
        ...config,
        configSchemaVersion: CONFIG_SCHEMA_VERSION,
        systemPromptJa: shouldUpgradePrompt(config.systemPromptJa, 'ja') ? DEFAULT_SYSTEM_PROMPT_JA : config.systemPromptJa,
        systemPromptEn: shouldUpgradePrompt(config.systemPromptEn, 'en') ? DEFAULT_SYSTEM_PROMPT_EN : config.systemPromptEn,
        updatedAt: new Date().toISOString()
      };
      await requestToPromise(txStore(db, 'config', 'readwrite').put(nextConfig));
    }

    const countReq = txStore(db, 'articles').count();
    const count = await requestToPromise(countReq);
    if (count === 0) {
      const samples = createSampleArticles();
      const articleStore = txStore(db, 'articles', 'readwrite');
      for (const article of samples) {
        articleStore.put(article);
      }
      await new Promise((resolve, reject) => {
        articleStore.transaction.oncomplete = resolve;
        articleStore.transaction.onerror = () => reject(articleStore.transaction.error);
      });
    }
  } finally {
    db.close();
  }
}

function shouldUpgradePrompt(prompt, lang) {
  const value = String(prompt || '');
  if (!value.trim()) return true;
  if (!value.includes('recommendation_items')) return true;
  if (lang === 'ja' && !value.includes('具体的な商品名')) return true;
  if (lang === 'en' && !value.includes('specific product names')) return true;
  return false;
}

function createSampleArticles() {
  const now = new Date().toISOString();
  return [
    {
      id: crypto.randomUUID(),
      title: '小麦アレルギーの人が食品表示で見るべき言葉',
      slug: 'wheat-allergy-label-check',
      excerpt: '小麦、グルテン、パン粉、しょうゆなど、食品表示で確認したい言葉を整理します。',
      body: `# 小麦アレルギーの人が食品表示で見るべき言葉\n\n食品表示では「小麦」だけでなく、パン粉、麺、しょうゆ、麦芽、グルテンなどの表記も確認が必要です。\n\n## 確認ポイント\n\n- 原材料名\n- アレルギー表示\n- 製造ラインや同一工場の注意書き\n- メーカー公式情報\n\nこのページは一般的な情報提供です。購入・飲食前に、必ず商品の原材料表示、アレルギー表示、メーカー公式情報を確認してください。`,
      category: '小麦',
      tags: ['小麦', 'グルテンフリー', '食品表示'],
      status: 'published',
      publishedAt: now,
      updatedAt: now,
      viewCount: 0
    },
    {
      id: crypto.randomUUID(),
      title: '乳成分不使用の商品を探すときの注意点',
      slug: 'milk-free-product-check',
      excerpt: '乳、脱脂粉乳、ホエイ、カゼイン、バターなど、乳由来成分の確認ポイントを整理します。',
      body: `# 乳成分不使用の商品を探すときの注意点\n\n乳成分は、牛乳、脱脂粉乳、全粉乳、ホエイ、カゼイン、バター、チーズなど、さまざまな名前で表示されることがあります。\n\n## 確認ポイント\n\n- 「乳成分を含む」の表示\n- ホエイ、カゼインなどの乳由来成分\n- 製造ラインや同一工場の注意書き\n\nこの記事は一般的な情報提供です。安全を保証するものではありません。`,
      category: '乳',
      tags: ['乳', '乳不使用', 'アレルギー'],
      status: 'published',
      publishedAt: now,
      updatedAt: now,
      viewCount: 0
    }
  ];
}

async function listArticles({ status = null } = {}) {
  const db = await openDb();
  try {
    const articles = await requestToPromise(txStore(db, 'articles').getAll());
    return articles
      .filter(article => !status || article.status === status)
      .sort((a, b) => String(b.publishedAt || '').localeCompare(String(a.publishedAt || '')));
  } finally {
    db.close();
  }
}

async function getArticleBySlug(slug) {
  const db = await openDb();
  try {
    const index = txStore(db, 'articles').index('slug');
    return await requestToPromise(index.get(slug));
  } finally {
    db.close();
  }
}

async function getArticleById(id) {
  const db = await openDb();
  try {
    return await requestToPromise(txStore(db, 'articles').get(id));
  } finally {
    db.close();
  }
}

async function saveArticle(article) {
  const db = await openDb();
  try {
    const now = new Date().toISOString();
    const existing = article.id ? await requestToPromise(txStore(db, 'articles').get(article.id)) : null;
    const saved = {
      id: article.id || crypto.randomUUID(),
      title: article.title || '',
      slug: slugify(article.slug || article.title || crypto.randomUUID()),
      excerpt: article.excerpt || '',
      body: article.body || '',
      category: article.category || '',
      tags: Array.isArray(article.tags) ? article.tags : String(article.tags || '').split(/[、,\n]/).map(v => v.trim()).filter(Boolean),
      status: article.status || 'draft',
      publishedAt: article.publishedAt || existing?.publishedAt || now,
      updatedAt: now,
      viewCount: existing?.viewCount || 0
    };
    await requestToPromise(txStore(db, 'articles', 'readwrite').put(saved));
    return saved;
  } finally {
    db.close();
  }
}

async function deleteArticle(id) {
  const db = await openDb();
  try {
    await requestToPromise(txStore(db, 'articles', 'readwrite').delete(id));
  } finally {
    db.close();
  }
}

async function incrementArticleView(id) {
  const article = await getArticleById(id);
  if (!article) return;
  article.viewCount = Number(article.viewCount || 0) + 1;
  await saveArticle(article);
}

async function logSearchEvent({ keyword, category = '', allergens = [], source = 'scan' }) {
  if (!keyword) return;
  const db = await openDb();
  try {
    const createdAt = new Date().toISOString();
    await requestToPromise(txStore(db, 'searchEvents', 'readwrite').add({ keyword, category, allergens, source, createdAt }));
    await upsertRankingInDb(db, { keyword, category, allergens, searchDelta: 1, clickDelta: 0 });
  } finally {
    db.close();
  }
}

async function logAffiliateClick({ provider, keyword, url, category = '', allergens = [] }) {
  const db = await openDb();
  try {
    const createdAt = new Date().toISOString();
    await requestToPromise(txStore(db, 'affiliateClicks', 'readwrite').add({ provider, keyword, url, category, allergens, createdAt }));
    if (keyword) {
      await upsertRankingInDb(db, { keyword, category, allergens, searchDelta: 0, clickDelta: 1 });
    }
  } finally {
    db.close();
  }
}

async function upsertRankingInDb(db, { keyword, category = '', allergens = [], searchDelta = 0, clickDelta = 0 }) {
  const store = txStore(db, 'rankings', 'readwrite');
  const current = await requestToPromise(store.get(keyword));
  const next = {
    keyword,
    category: category || current?.category || '',
    allergens: allergens?.length ? allergens : (current?.allergens || []),
    count: Number(current?.count || 0) + searchDelta,
    clickCount: Number(current?.clickCount || 0) + clickDelta,
    score: Number(current?.score || 0) + searchDelta + clickDelta * 3,
    updatedAt: new Date().toISOString()
  };
  await requestToPromise(store.put(next));
}

async function listRankings(limit = 50) {
  const db = await openDb();
  try {
    const rankings = await requestToPromise(txStore(db, 'rankings').getAll());
    return rankings.sort((a, b) => Number(b.score || 0) - Number(a.score || 0)).slice(0, limit);
  } finally {
    db.close();
  }
}

async function listEvents(storeName, limit = 100) {
  const db = await openDb();
  try {
    const rows = await requestToPromise(txStore(db, storeName).getAll());
    return rows.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))).slice(0, limit);
  } finally {
    db.close();
  }
}

async function exportAllData() {
  const db = await openDb();
  try {
    const result = {};
    for (const storeName of ['config', 'articles', 'rankings', 'searchEvents', 'affiliateClicks']) {
      result[storeName] = await requestToPromise(txStore(db, storeName).getAll());
    }
    result.exportedAt = new Date().toISOString();
    result.dbName = DB_NAME;
    result.dbVersion = DB_VERSION;
    return result;
  } finally {
    db.close();
  }
}

async function importAllData(data) {
  const db = await openDb();
  try {
    for (const storeName of ['config', 'articles', 'rankings', 'searchEvents', 'affiliateClicks']) {
      if (!Array.isArray(data[storeName])) continue;
      const store = txStore(db, storeName, 'readwrite');
      await requestToPromise(store.clear());
      for (const row of data[storeName]) {
        store.put(row);
      }
      await new Promise((resolve, reject) => {
        store.transaction.oncomplete = resolve;
        store.transaction.onerror = () => reject(store.transaction.error);
      });
    }
  } finally {
    db.close();
  }
}

function slugify(input) {
  return String(input || '')
    .trim()
    .toLowerCase()
    .normalize('NFKC')
    .replace(/[\s_]+/g, '-')
    .replace(/[^a-z0-9\-ぁ-んァ-ン一-龥]/g, '')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '') || crypto.randomUUID();
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function escapeAttribute(value) {
  return escapeHtml(value).replace(/`/g, '&#096;');
}

function normalizeText(value) {
  return String(value || '').toLowerCase().normalize('NFKC').replace(/\s+/g, '');
}

function toArray(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value.map(v => String(v).trim()).filter(Boolean);
  return String(value).split(/[、,\n]/).map(v => v.trim()).filter(Boolean);
}

function uniqueArray(list) {
  const seen = new Set();
  const result = [];
  for (const item of list || []) {
    const normalized = normalizeText(item);
    if (!normalized || seen.has(normalized)) continue;
    seen.add(normalized);
    result.push(item);
  }
  return result;
}


// Added for fast allergen checking and judgement comparison.
DEFAULT_CONFIG.fastAllergenCheckEnabled = true;
DEFAULT_CONFIG.ocrEngine = 'gemini';
DEFAULT_CONFIG.judgementEngine = 'local';
DEFAULT_CONFIG.productPhotoMode = 'rakuten';
